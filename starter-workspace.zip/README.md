# Your AI Workspace — starter kit

A folder your AI reads every session, so it already knows your sources,
your standards, and your voice. Set it up once; reuse it for everything.

## What's in here

| | |
|---|---|
| `INSTRUCTIONS.md` | The contract your AI reads first. Open it and fill in the one blank ("what we're doing"). |
| `sources/` | Drop in the papers and documents you're reading or citing. |
| `rubric/` | The standards you hold work to: `reading-a-paper.md` (how to read a paper or report) and `your-standard.md` (a blank template for what "good" means on your project). |
| `drafts/` | Your writing and outputs. |

## How to use it

Point your AI at the documents your project actually runs on. Use it to
read and understand them faster, to see what the project really turns on,
and to check your own writing against a standard. Fill in
`rubric/your-standard.md` with whatever your work is held to.

The skill is the same whatever the project: **give the AI a home, teach it
to read with you, and never let it invent what it doesn't know.**

## Setup — once

1. Put this folder where you'll find it. If you work with others, put it in
   a shared drive (Box / Dropbox) so everyone reads the same copy.
2. Open `INSTRUCTIONS.md`, fill in the one blank, and either:
   - **Rung 2 (a Project / Gem):** paste `INSTRUCTIONS.md` into the custom-
     instructions box and upload the `sources/` and `rubric/` files, or
   - **Rung 3 (a folder on your computer):** just leave it here — your agent
     reads it.
3. Drop a paper into `sources/` and say: *"Walk me through this paper using
   `rubric/reading-a-paper.md`."*
