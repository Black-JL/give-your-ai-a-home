# sources/

Drop the papers and documents you're **reading or citing** in here — PDFs,
articles, reports, anything your claims will rest on.

Your AI is told (in `../INSTRUCTIONS.md`) to trace every factual claim back
to a file in this folder, and never to invent a source it doesn't have.
So the rule is simple: **if it's not in here, it's not a source yet.**
