# Your standard — what "good" means for this project

Fill this in once. Your AI checks your work against it before you revise:
*"Check my draft against `rubric/your-standard.md`. Mark each item PASS /
WEAK / FAIL and say why. Don't rewrite it — tell me what to fix."*

Paste in whatever your work is actually held to: a policy format, an SOP
template, a style guide, a decision-brief outline, a boss's past edits, an
example you're matching. Or write your own below.

## Format
- Length:
- Audience:
- Style: (e.g., bottom line up front, active voice, plain language)

## Must contain
1.
2.
3.

## Integrity — non-negotiable
- **No fabricated data or sources.** Every claim traces to a real file in
  `sources/`.
- **Edited and owned by you** — it represents your final judgment,
  whatever level of AI help you used.
- **Disclose the AI** — which model(s) you used and how.
