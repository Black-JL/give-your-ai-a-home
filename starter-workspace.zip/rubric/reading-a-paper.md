# How to read a paper — a checklist you can hand to your AI

You don't need to be a statistician to read a paper well. You need to ask
the same questions every time. Work through these with your AI, using the
paper in `sources/`. Tell your AI: *"Walk me through this paper using
`rubric/reading-a-paper.md`. Don't lead the witness — tell me what's strong
and what's weak."*

## 1. The claim
- In one sentence, what does this paper say is true?
- Who would act differently if they believed it?

## 2. The evidence
- What did they actually measure or observe? (Not what they concluded —
  what they *did*.)
- How many? Over what period? Compared to what?

## 3. The assumptions
- What has to be true for their conclusion to follow? (State the obvious ones.)
- What did they assume *without saying*? Ask your AI to itemize the
  **implicit** assumptions — this is where papers quietly break.

## 4. The gap between measured and claimed
- Did they measure the thing in the headline, or a stand-in for it?
- Is the sample they studied the population they're generalizing to?

## 5. Conflicts and incentives
- Who funded it? Who benefits if the result is true?
- Were the people judging the result the same people who ran the study?

## 6. How strong is it, really?
- On a scale from "settles it" to "suggestive," where does this land — and why?
- What one piece of evidence would change your mind?

## 7. How you'll use it
- Can you state its finding in your own words *without the paper open*? If
  not, you don't understand it yet — ask your AI to explain it again, simpler.
- What is the exact, correct citation? Have your AI pull it **from the paper
  itself** — never let it invent one.
