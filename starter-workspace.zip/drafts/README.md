# drafts/

Your writing and outputs land here — outlines, drafts, the versions your
work goes through, and anything the AI renders for you.

Keep versions rather than overwriting (e.g. `brief-v1.md`,
`brief-v2.md`) so you can see how the thinking changed — and so you
can always get back to a version you liked.
